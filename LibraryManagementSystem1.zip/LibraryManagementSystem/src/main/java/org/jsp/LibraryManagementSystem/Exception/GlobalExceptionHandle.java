package org.jsp.LibraryManagementSystem.Exception;

import org.jsp.LibraryManagementSystem.dto.ResponseStructure;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandle extends ResponseEntityExceptionHandler {

	@ExceptionHandler(IdNotFoundExceptionClass.class)
	public ResponseEntity<ResponseStructure<String>> handleId(IdNotFoundExceptionClass excep){
		ResponseStructure<String> struc=new ResponseStructure<String>();
		struc.setStatusCode(HttpStatus.NOT_FOUND.value());
		struc.setData(excep.getMessage());
		struc.setMessage("Not Found");
		return new  ResponseEntity<ResponseStructure<String>>(struc,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(ListEmptyClass.class)
	public ResponseEntity<ResponseStructure<String>> handleId(ListEmptyClass excep){
		ResponseStructure<String> struc=new ResponseStructure<String>();
		struc.setStatusCode(HttpStatus.NOT_FOUND.value());
		struc.setData(excep.getMessage());
		struc.setMessage("No Records Found");
		return new  ResponseEntity<ResponseStructure<String>>(struc,HttpStatus.NOT_FOUND);
	
}
}