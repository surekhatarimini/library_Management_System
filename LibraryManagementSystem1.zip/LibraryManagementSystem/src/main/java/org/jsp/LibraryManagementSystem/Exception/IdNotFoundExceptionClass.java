package org.jsp.LibraryManagementSystem.Exception;

public class IdNotFoundExceptionClass extends RuntimeException{
@Override
public String getMessage() {
	return "Id Not Available";
}
}
