package org.jsp.LibraryManagementSystem.Exception;

public class ListEmptyClass extends RuntimeException{
	@Override
	public String getMessage() {
		return "List Size is empty";
	}
}
