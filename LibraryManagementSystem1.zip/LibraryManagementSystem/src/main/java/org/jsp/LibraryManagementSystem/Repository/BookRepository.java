package org.jsp.LibraryManagementSystem.Repository;

import java.util.List;

import org.jsp.LibraryManagementSystem.Entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface BookRepository extends JpaRepository<Book,Integer> {


	@Query("select b from Book b where b.genere=?1")
	List<Book> getBooksByGener(String gener);
	

}
