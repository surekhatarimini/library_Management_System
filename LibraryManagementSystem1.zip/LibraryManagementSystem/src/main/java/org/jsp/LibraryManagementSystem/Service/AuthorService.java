package org.jsp.LibraryManagementSystem.Service;

import java.util.List;
import java.util.Optional;


import org.jsp.LibraryManagementSystem.Entity.Author;
import org.jsp.LibraryManagementSystem.Exception.IdNotFoundExceptionClass;
import org.jsp.LibraryManagementSystem.Repository.AuthorRepository;
import org.jsp.LibraryManagementSystem.dao.Authordao;
import org.jsp.LibraryManagementSystem.dto.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class AuthorService {
 
	@Autowired
	private Authordao authorDao;
	
	public ResponseEntity<ResponseStructure<Author>> saveAuhotr(Author author){
		Author receivedAuthor=authorDao.saveAuthor(author);
		ResponseStructure<Author> structure=new ResponseStructure<Author>();
		structure.setStatusCode(HttpStatus.CREATED.value());
		structure.setMessage("Success");
		structure.setData(receivedAuthor);
		return new ResponseEntity<ResponseStructure<Author>>(structure,HttpStatus.CREATED);
		
	}
	
	public ResponseEntity<ResponseStructure<List<Author>>> getAllAuthors(){
		List<Author> recievedAtuhor=authorDao.GetAllAuthor();
		ResponseStructure<List<Author>> structure=new ResponseStructure<List<Author>>();
		
			structure.setStatusCode(HttpStatus.OK.value());
			structure.setMessage("Success");
			structure.setData(recievedAtuhor);
			return new  ResponseEntity<ResponseStructure<List<Author>>>(structure,HttpStatus.OK);
		
		
	}
	public ResponseEntity<ResponseStructure<Author>> getAuthorById(int id){
		Author auth=authorDao.returnAuthor(id);
		ResponseStructure<Author> structure=new ResponseStructure<Author>();
		
		if(auth!=null) {
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Success");
		structure.setData(auth);
		
		return new ResponseEntity<ResponseStructure<Author>>(structure,HttpStatus.OK);
		}
		else {
			 throw new IdNotFoundExceptionClass();
		}
		
	}
	 public  ResponseEntity<ResponseStructure<Author>> DeleteRecord(int id){
		 ResponseStructure<Author> structure=new ResponseStructure<Author>();
		Optional<Author> op=authorDao.DeleteRecord(id);
		
		if(op.isPresent()) {
			 authorDao.DeleteRecord(id);
			 structure.setStatusCode(HttpStatus.OK.value());
			 structure.setMessage("Dleted Successfully");
			 structure.setData(null);
			 return new ResponseEntity<ResponseStructure<Author>>(structure,HttpStatus.OK);
		 }
		 else {
			 throw new IdNotFoundExceptionClass();
		 }
	 }
	 
	 public ResponseEntity<ResponseStructure<Author>> updateAuthor(Author author){
			Author updateAuthor=authorDao.updateAuthor(author);
			ResponseStructure<Author> structure=new ResponseStructure<Author>();
			structure.setStatusCode(HttpStatus.OK.value());
			structure.setMessage("Success");
			structure.setData(updateAuthor);
			
			return new ResponseEntity<ResponseStructure<Author>>(structure,HttpStatus.OK);
			
		}
	

}
