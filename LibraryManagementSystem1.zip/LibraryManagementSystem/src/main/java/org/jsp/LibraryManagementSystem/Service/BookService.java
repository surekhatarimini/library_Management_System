package org.jsp.LibraryManagementSystem.Service;

import java.util.List;
import java.util.Optional;

import org.jsp.LibraryManagementSystem.Entity.Author;
import org.jsp.LibraryManagementSystem.Entity.Book;
import org.jsp.LibraryManagementSystem.Exception.IdNotFoundExceptionClass;
import org.jsp.LibraryManagementSystem.dao.Bookdao;
import org.jsp.LibraryManagementSystem.dto.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class BookService {

	@Autowired
	private Bookdao bookdao;
	
	public ResponseEntity<ResponseStructure<Book>> saveBook(Book book){
		Book receivedBook=bookdao.saveBook(book);
		ResponseStructure<Book> struc=new ResponseStructure<Book>();
		struc.setStatusCode(HttpStatus.CREATED.value());
		struc.setMessage("Created");
		struc.setData(receivedBook);
		return new  ResponseEntity<ResponseStructure<Book>>(struc,HttpStatus.CREATED);
	}
	
	public ResponseEntity<ResponseStructure<List<Book>>> getAllBooks(){
		List<Book> listBooks=bookdao.getAllBooks();
		ResponseStructure<List<Book>> struc=new ResponseStructure<List<Book>>();
		struc.setStatusCode(HttpStatus.OK.value());
		struc.setMessage("Found");
		struc.setData(listBooks);
		return new  ResponseEntity<ResponseStructure<List<Book>>>(struc,HttpStatus.OK);
		
	}
	
	
	public ResponseEntity<ResponseStructure<Book>> getBookById(int id){
		Book book=bookdao.returnBook(id);
		ResponseStructure<Book> structure=new ResponseStructure<Book>();
		if(book!=null) {
			structure.setStatusCode(HttpStatus.OK.value());
			structure.setMessage("Success");
			structure.setData(book);
			
			return new ResponseEntity<ResponseStructure<Book>>(structure,HttpStatus.OK);
		}
		else {
			 throw new IdNotFoundExceptionClass();
		}
		
		
		
	}
	public ResponseEntity<ResponseStructure<List<Book>>> getBookByGener( String gener){
		List<Book> listBooks=bookdao.returnBookByGenre(gener);
		ResponseStructure<List<Book>> struc=new ResponseStructure<List<Book>>();
		struc.setStatusCode(HttpStatus.OK.value());
		struc.setMessage("Found");
		struc.setData(listBooks);
		return new  ResponseEntity<ResponseStructure<List<Book>>>(struc,HttpStatus.OK);
	}
	
	public  ResponseEntity<ResponseStructure<Book>> DeleteRecord(int id){
		Optional<Book> op=bookdao.DeleteRecord(id);
		 ResponseStructure<Book> structure=new ResponseStructure<Book>();
		 if(op.isPresent()) {
		  bookdao.DeleteRecord(id);
		
		 structure.setStatusCode(HttpStatus.OK.value());
		 structure.setMessage("Deleted Successfully");
		 structure.setData(null);
		 return new ResponseEntity<ResponseStructure<Book>>(structure,HttpStatus.OK);
	 }
		 else {
			 throw new IdNotFoundExceptionClass();
		 }
	}
	
	 
	
	public ResponseEntity<ResponseStructure<Book>> update(Book book){
		Book receivedBook=bookdao.updateBook(book);
		ResponseStructure<Book> struc=new ResponseStructure<Book>();
		struc.setStatusCode(HttpStatus.OK.value());
		struc.setMessage("Updated");
		struc.setData(receivedBook);
		return new  ResponseEntity<ResponseStructure<Book>>(struc,HttpStatus.OK);
	}
	
}
