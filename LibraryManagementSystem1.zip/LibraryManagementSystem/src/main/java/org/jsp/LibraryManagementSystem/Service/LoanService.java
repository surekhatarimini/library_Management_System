package org.jsp.LibraryManagementSystem.Service;

import java.util.List;
import java.util.Optional;

import org.jsp.LibraryManagementSystem.Entity.Loan;
import org.jsp.LibraryManagementSystem.Exception.IdNotFoundExceptionClass;
import org.jsp.LibraryManagementSystem.dao.Loandao;
import org.jsp.LibraryManagementSystem.dto.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class LoanService {
	@Autowired
	private Loandao loanDao;

	public ResponseEntity<ResponseStructure<Loan>> saveLoan(Loan loan){
		Loan receivedLoan=loanDao.saveLoan(loan);
		ResponseStructure<Loan> structure=new ResponseStructure<Loan>();
		structure.setStatusCode(HttpStatus.CREATED.value());
		structure.setMessage("Success");
		structure.setData(receivedLoan);
		return new ResponseEntity<ResponseStructure<Loan>>(structure,HttpStatus.CREATED);
		
	}

	public ResponseEntity<ResponseStructure<List<Loan>>> getAllLoan(){
		List<Loan> recievedLoan=loanDao.GetAllLoan();
		ResponseStructure<List<Loan>> structure=new ResponseStructure<List<Loan>>();
		
			structure.setStatusCode(HttpStatus.OK.value());
			structure.setMessage("Success");
			structure.setData(recievedLoan);
			return new  ResponseEntity<ResponseStructure<List<Loan>>>(structure,HttpStatus.OK);
		
		
	}
	public ResponseEntity<ResponseStructure<Loan>> getLoanById(int id){
		Loan loan=loanDao.returnLoan(id);
		ResponseStructure<Loan> structure=new ResponseStructure<Loan>();
		
		if(loan!=null) {
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Success");
		structure.setData(loan);
		
		return new ResponseEntity<ResponseStructure<Loan>>(structure,HttpStatus.OK);
		}
		else {
			 throw new IdNotFoundExceptionClass();
		}
		
	}
	 public  ResponseEntity<ResponseStructure<Loan>> DeleteRecord(int id){
		 ResponseStructure<Loan> structure=new ResponseStructure<Loan>();
		 Optional<Loan> op=loanDao.DeleteRecord(id);
		 if(op.isPresent()) {
			 loanDao.DeleteRecord(id);
			 structure.setStatusCode(HttpStatus.OK.value());
			 structure.setMessage("Dleted Successfully");
			 structure.setData(null);
			 return new ResponseEntity<ResponseStructure<Loan>>(structure,HttpStatus.OK);
		 }
		 else {
			 throw new IdNotFoundExceptionClass();
		 }
	 }
	 
	 public ResponseEntity<ResponseStructure<Loan>> updateLoan(Loan loan){
			Loan updateAuthor=loanDao.updateLoan(loan);
			ResponseStructure<Loan> structure=new ResponseStructure<Loan>();
			structure.setStatusCode(HttpStatus.OK.value());
			structure.setMessage("Success");
			structure.setData(updateAuthor);
			
			return new ResponseEntity<ResponseStructure<Loan>>(structure,HttpStatus.OK);
			
		}
}
