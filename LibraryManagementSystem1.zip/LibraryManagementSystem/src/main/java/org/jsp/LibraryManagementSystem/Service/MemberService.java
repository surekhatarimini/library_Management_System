package org.jsp.LibraryManagementSystem.Service;

import java.util.List;
import java.util.Optional;

import org.jsp.LibraryManagementSystem.Entity.Member;
import org.jsp.LibraryManagementSystem.Exception.IdNotFoundExceptionClass;
import org.jsp.LibraryManagementSystem.dao.Memberdao;
import org.jsp.LibraryManagementSystem.dto.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class MemberService {
	@Autowired
	private Memberdao memberDao;
	
	public ResponseEntity<ResponseStructure<Member>> saveMember(Member member){
		Member receivedMember=memberDao.saveMember(member);
		ResponseStructure<Member> structure=new ResponseStructure<Member>();
		structure.setStatusCode(HttpStatus.CREATED.value());
		structure.setMessage("Success");
		structure.setData(receivedMember);
		return new ResponseEntity<ResponseStructure<Member>>(structure,HttpStatus.CREATED);
		
	}
	
	public ResponseEntity<ResponseStructure<List<Member>>> getAllMeber(){
		List<Member> recievedMembers=memberDao.GetAllMember();
		ResponseStructure<List<Member>> structure=new ResponseStructure<List<Member>>();
		
			structure.setStatusCode(HttpStatus.OK.value());
			structure.setMessage("Success");
			structure.setData(recievedMembers);
			return new  ResponseEntity<ResponseStructure<List<Member>>>(structure,HttpStatus.OK);
		
		
	}
	public ResponseEntity<ResponseStructure<Member>> getMemberById(int id){
		Member mem=memberDao.returnMember(id);
		ResponseStructure<Member> structure=new ResponseStructure<Member>();
		
		if(mem!=null) {
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Success");
		structure.setData(mem);
		
		return new ResponseEntity<ResponseStructure<Member>>(structure,HttpStatus.OK);
		}
		else {
			 throw new IdNotFoundExceptionClass();
		}
		
	}
	 public  ResponseEntity<ResponseStructure<Member>> DeleteRecord(int id){
		 ResponseStructure<Member> structure=new ResponseStructure<Member>();
		 Optional<Member> op=memberDao.DeleteRecord(id);
		 if(op.isPresent()) {
			 memberDao.DeleteRecord(id);
			 structure.setStatusCode(HttpStatus.OK.value());
			 structure.setMessage("Dleted Successfully");
			 structure.setData(null);
			 return new ResponseEntity<ResponseStructure<Member>>(structure,HttpStatus.OK);
		 }
		 else {
			 throw new IdNotFoundExceptionClass();
		 }
	 }
	 
	 public ResponseEntity<ResponseStructure<Member>> updateMember(Member member){
			Member updateAuthor=memberDao.updateMember(member);
			ResponseStructure<Member> structure=new ResponseStructure<Member>();
			structure.setStatusCode(HttpStatus.OK.value());
			structure.setMessage("Success");
			structure.setData(updateAuthor);
			
			return new ResponseEntity<ResponseStructure<Member>>(structure,HttpStatus.OK);
			
		}
	
}
