package org.jsp.LibraryManagementSystem.dao;

import java.util.List;
import java.util.Optional;

import org.jsp.LibraryManagementSystem.Entity.Author;
import org.jsp.LibraryManagementSystem.Repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Repository
public class Authordao {
	@Autowired
	private AuthorRepository authorRepos;
	
	public Author saveAuthor(Author author) {
		return authorRepos.save(author);
	}
	
	public List<Author> GetAllAuthor() {
		return authorRepos.findAll();
	}
    
	public Author returnAuthor(@PathVariable int id) {
		Optional<Author> op=authorRepos.findById(id);
		return op.get();
		
		
	}
	public Optional<Author> DeleteRecord(@PathVariable int id) {
		Optional<Author> op=authorRepos.findById(id);
		authorRepos.deleteById(id);
	    return op;	 
	}
	
	public Author updateAuthor(@RequestBody Author author) {
		return authorRepos.save(author);
	}




}
