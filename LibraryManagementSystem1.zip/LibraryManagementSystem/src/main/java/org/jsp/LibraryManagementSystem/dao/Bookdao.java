package org.jsp.LibraryManagementSystem.dao;

import java.util.List;
import java.util.Optional;

import org.jsp.LibraryManagementSystem.Entity.Author;
import org.jsp.LibraryManagementSystem.Entity.Book;
import org.jsp.LibraryManagementSystem.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Repository
public class Bookdao {
     @Autowired
     private BookRepository bookRepo;
     
     public Book saveBook(@RequestBody Book book) {
    	 return bookRepo.save(book);
     }
     public List<Book> getAllBooks(){
    	 return bookRepo.findAll();
     }
     public Book returnBook(@PathVariable int id) {
    	 Optional<Book> op=bookRepo.findById(id);
    	 return op.get();
     }
     
     public List<Book> returnBookByGenre(@PathVariable String gener) {
    	 return bookRepo.getBooksByGener(gener);
     }
     
 	public Optional<Book> DeleteRecord(@PathVariable int id) {
		Optional<Book> op=bookRepo.findById(id);
		bookRepo.deleteById(id);
	    return op;	 
	}
     
	public Book updateBook(@RequestBody Book book) {
		  return bookRepo.save(book);
	}

}
