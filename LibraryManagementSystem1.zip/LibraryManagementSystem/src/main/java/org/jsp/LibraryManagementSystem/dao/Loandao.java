package org.jsp.LibraryManagementSystem.dao;

import java.util.List;
import java.util.Optional;

import org.jsp.LibraryManagementSystem.Entity.Loan;
import org.jsp.LibraryManagementSystem.Repository.LoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Repository
public class Loandao {
	@Autowired
	private LoanRepository loanrepo;
	
	public Loan saveLoan(Loan loan) {
		return loanrepo.save(loan);
	}
	
	public List<Loan> GetAllLoan() {
		return loanrepo.findAll();
	}
    
	public Loan returnLoan(@PathVariable int id) {
		Optional<Loan> op=loanrepo.findById(id);
		return op.get();
	}
	public Optional<Loan> DeleteRecord(@PathVariable int id) {
		Optional<Loan> op=loanrepo.findById(id);
		loanrepo.deleteById(id);
	    return op;	 
	}
	
	public Loan updateLoan(@RequestBody Loan loan) {
		return loanrepo.save(loan);
	}
}
