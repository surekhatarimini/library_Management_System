package org.jsp.LibraryManagementSystem.dao;

import java.util.List;
import java.util.Optional;

import org.jsp.LibraryManagementSystem.Entity.Member;
import org.jsp.LibraryManagementSystem.Repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

@Repository
public class Memberdao {
	@Autowired
	private MemberRepository memrepo;
	
	public Member saveMember(Member member) {
		return memrepo.save(member);
	}
	
	public List<Member> GetAllMember() {
		return memrepo.findAll();
	}
    
	public Member returnMember(@PathVariable int id) {
		Optional<Member> op=memrepo.findById(id);
		return op.get();
	}
	public Optional<Member> DeleteRecord(@PathVariable int id) {
		Optional<Member> op=memrepo.findById(id);
		memrepo.deleteById(id);
	    return op;	 
	}
	
	public Member updateMember(@RequestBody Member member) {
		return memrepo.save(member);
	}

}
